<div class="connexion-container">
    <div class="connexion-box">
        <div class="connexion-form">
            <form method="post" action="connexion/check">
                <input id="surnom" name="surnom" type="text" placeholder="Votre pseudo"
                       required /><br />
                <input id="mdp" name="mdp" type="password"
                       placeholder="Votre mot de pass" required>  <br />

                <input id="login" name = "login"   type="submit" value="Se connecter" />

                <input id="sign_up" name="sign_up" type="submit" value="S'inscrir" />
            </form>
        </div>
    </div>
</div>